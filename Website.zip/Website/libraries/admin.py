from django.contrib import admin
from libraries.models import Library
from libraries.models import Colleges

admin.site.register(Library)
admin.site.register(Colleges)
