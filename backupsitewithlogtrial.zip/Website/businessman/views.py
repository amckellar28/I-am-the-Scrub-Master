from django.shortcuts import render
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required
def index(request):
	return render(request, 'businessman/home.html')

@login_required	
def cityinformation(request):
	return render(request, 'businessman/cityinformation.html')

@login_required	
def citymap(request):
	return render(request, 'businessman/citymap.html')