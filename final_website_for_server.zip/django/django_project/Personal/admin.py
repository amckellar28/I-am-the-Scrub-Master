from django.contrib import admin
from Personal.models import Event

admin.site.register(Event)
