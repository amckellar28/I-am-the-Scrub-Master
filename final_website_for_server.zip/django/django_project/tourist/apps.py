from django.apps import AppConfig


class TouristConfig(AppConfig):
    name = 'tourist'
